export interface member {
  id: Token
  name: string
}

export type Token = string;
